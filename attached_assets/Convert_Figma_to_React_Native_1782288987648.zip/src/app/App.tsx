import { useState } from "react";
import imgLkd from "../imports/Onboarding1/77dcff6aeaa5b3e1fa00ad6a7d0bb6ce4dc11c95.png";
import imgEWallet from "../imports/Onboarding1/2834e1bb0bf08d81d90ee9230673f42dab798c47.png";
import imgAvatar from "../imports/UserDashBoard/9b19bc03f645625ddb77cba0433d55782d515d52.png";
import {
  Home,
  CreditCard,
  History,
  PlusCircle,
  Navigation,
  ArrowDownToLine,
  Zap,
  Tv2,
  BarChart2,
  AlignJustify,
  Wallet,
  LayoutGrid,
  Gift,
  Settings2,
  Eye,
  EyeOff,
  ChevronRight,
  ArrowUpRight,
  ArrowDownLeft,
} from "lucide-react";

// ─── STATUS BAR ────────────────────────────────────────────────────────────────
function StatusBar() {
  return (
    <div className="flex items-center justify-between px-6 pt-3 pb-1 h-12">
      <span
        className="text-white text-[11px] font-semibold tracking-[-0.3px]"
        style={{ fontFamily: "Manrope, sans-serif" }}
      >
        9:41
      </span>
      <div className="flex items-center gap-1.5">
        {/* Cellular */}
        <svg width="17" height="12" viewBox="0 0 17 12" fill="none">
          <rect x="0" y="8" width="3" height="4" rx="0.6" fill="white" />
          <rect x="4.5" y="5" width="3" height="7" rx="0.6" fill="white" />
          <rect x="9" y="2.5" width="3" height="9.5" rx="0.6" fill="white" />
          <rect x="13.5" y="0" width="3" height="12" rx="0.6" fill="white" />
        </svg>
        {/* Wifi */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
          <path
            d="M8 9.5C8.8 9.5 9.5 10.2 9.5 11C9.5 11.8 8.8 12.5 8 12.5C7.2 12.5 6.5 11.8 6.5 11C6.5 10.2 7.2 9.5 8 9.5Z"
            fill="white"
          />
          <path
            d="M8 6C9.7 6 11.2 6.7 12.3 7.8L13.7 6.4C12.2 4.9 10.2 4 8 4C5.8 4 3.8 4.9 2.3 6.4L3.7 7.8C4.8 6.7 6.3 6 8 6Z"
            fill="white"
            opacity="0.7"
          />
          <path
            d="M8 2C11.1 2 13.9 3.3 15.8 5.4L17.2 4C15 1.5 11.7 0 8 0C4.3 0 1 1.5-1.2 4L0.2 5.4C2.1 3.3 4.9 2 8 2Z"
            fill="white"
            opacity="0.4"
          />
        </svg>
        {/* Battery */}
        <svg width="27" height="13" viewBox="0 0 27 13" fill="none">
          <rect
            x="0.5"
            y="0.5"
            width="22"
            height="12"
            rx="2.5"
            stroke="white"
            strokeOpacity="0.35"
            strokeWidth="1"
          />
          <rect x="1.5" y="1.5" width="19" height="10" rx="1.5" fill="white" />
          <path
            d="M24 4.5H25C25.6 4.5 26 4.9 26 5.5V7.5C26 8.1 25.6 8.5 25 8.5H24V4.5Z"
            fill="white"
            fillOpacity="0.4"
          />
        </svg>
      </div>
    </div>
  );
}

// ─── ONBOARDING SCREEN ─────────────────────────────────────────────────────────
function OnboardingScreen({ onNavigate }: { onNavigate: () => void }) {
  const [dot, setDot] = useState(0);

  return (
    <div
      className="flex flex-col h-full"
      style={{ background: "linear-gradient(160deg, #0C0E1A 0%, #080B14 100%)" }}
    >
      <StatusBar />

      {/* Logo */}
      <div className="flex justify-center mt-2">
        <img
          src={imgLkd}
          alt="AZA"
          className="h-5 object-contain"
          style={{ filter: "invert(1)" }}
        />
      </div>

      {/* Hero illustration */}
      <div className="flex-1 flex items-center justify-center mx-8 mt-3">
        <div
          className="w-full relative overflow-hidden"
          style={{ aspectRatio: "1 / 1", borderRadius: 20 }}
        >
          {/* Subtle glow behind illustration */}
          <div
            className="absolute inset-0"
            style={{
              background:
                "radial-gradient(ellipse at 50% 50%, rgba(0,220,200,0.08) 0%, rgba(0,0,0,0) 70%)",
            }}
          />
          <img
            src={imgEWallet}
            alt="E-Wallet"
            className="absolute inset-0 w-full h-full object-cover"
            style={{ mixBlendMode: "luminosity", opacity: 0.92 }}
          />
          {/* Overlay labels matching original */}
          <div
            className="absolute"
            style={{
              left: "50%",
              transform: "translateX(-50%)",
              top: "38%",
              width: "30%",
              textAlign: "center",
            }}
          >
            <span
              className="text-[#1A2530] text-[9px] font-medium"
              style={{ fontFamily: "sans-serif" }}
            >
              Withdraw
            </span>
          </div>
          <div
            className="absolute"
            style={{
              left: "50%",
              transform: "translateX(-50%)",
              top: "49%",
              width: "30%",
              textAlign: "center",
            }}
          >
            <span
              className="text-[#1A2530] text-[8px]"
              style={{ fontFamily: "sans-serif" }}
            >
              ₦200,000
            </span>
          </div>
        </div>
      </div>

      {/* Page indicators */}
      <div className="flex justify-center items-center gap-2 mt-5 mb-4">
        {[0, 1, 2].map((i) => (
          <button
            key={i}
            onClick={() => setDot(i)}
            className="transition-all duration-300 rounded-full"
            style={{
              width: i === dot ? 20 : 8,
              height: 8,
              backgroundColor:
                i === dot ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.2)",
            }}
          />
        ))}
      </div>

      {/* Headline */}
      <div className="text-center px-10 mb-5">
        <h1
          className="text-white font-semibold leading-tight"
          style={{ fontFamily: "Montserrat, sans-serif", fontSize: 26 }}
        >
          Withdraw like a Boss
        </h1>
        <p
          className="mt-2 uppercase tracking-widest"
          style={{
            fontFamily: "Roboto, sans-serif",
            fontSize: 11,
            color: "rgba(255,255,255,0.4)",
            letterSpacing: "0.12em",
          }}
        >
          buy your gift card on aza
        </p>
      </div>

      {/* CTA Buttons */}
      <div className="px-14 pb-10 flex flex-col gap-3">
        <button
          onClick={onNavigate}
          className="w-full font-semibold text-sm py-4 rounded-lg transition-all active:scale-95"
          style={{
            fontFamily: "Roboto, sans-serif",
            background: "white",
            color: "#0A0C14",
          }}
        >
          Login
        </button>
        <button
          onClick={onNavigate}
          className="w-full font-semibold text-sm py-4 rounded-lg transition-all active:scale-95"
          style={{
            fontFamily: "Roboto, sans-serif",
            color: "white",
            border: "1px solid rgba(255,255,255,0.3)",
            background: "transparent",
          }}
        >
          Sign Up
        </button>
      </div>
    </div>
  );
}

// ─── DASHBOARD SCREEN ──────────────────────────────────────────────────────────
function DashboardScreen() {
  const [balanceVisible, setBalanceVisible] = useState(true);
  const [activeNav, setActiveNav] = useState(0);

  const services = [
    { icon: <Gift size={18} strokeWidth={1.5} />, label: "Gift Card", color: "#FFE0CF" },
    {
      icon: <Settings2 size={18} strokeWidth={1.5} />,
      label: "Settings",
      color: "#BCE2FE",
    },
    {
      icon: <Zap size={18} strokeWidth={1.5} />,
      label: "Electricity",
      color: "#FFF2CF",
    },
    { icon: <Tv2 size={18} strokeWidth={1.5} />, label: "Cable TV", color: "#FCB3C5" },
    {
      icon: <BarChart2 size={18} strokeWidth={1.5} />,
      label: "Rates",
      color: "#D6E1FF",
    },
    {
      icon: <AlignJustify size={18} strokeWidth={1.5} />,
      label: "Transaction",
      color: "#D6E1FF",
    },
    {
      icon: <Wallet size={18} strokeWidth={1.5} />,
      label: "Bet Funding",
      color: "#BCE2FE",
    },
    {
      icon: <LayoutGrid size={18} strokeWidth={1.5} />,
      label: "More",
      color: "#D6E1FF",
    },
  ];

  const transactions = [
    {
      icon: <ArrowDownLeft size={15} />,
      iconBg: "#1A2A1A",
      iconColor: "#00D17E",
      title: "Deposit Giftcard",
      date: "February 24, 2022",
      amount: "₦200,40.00",
      positive: true,
    },
    {
      icon: <ArrowUpRight size={15} />,
      iconBg: "#2A1A1A",
      iconColor: "#FF3366",
      title: "Withdraws",
      date: "February 24, 2022",
      amount: "₦400,000.00",
      positive: false,
    },
  ];

  return (
    <div
      className="flex flex-col h-full overflow-y-auto"
      style={{ background: "#080B14" }}
    >
      <StatusBar />

      {/* AZA Logo */}
      <div className="flex justify-center py-1">
        <span
          className="text-white text-xl font-bold tracking-widest"
          style={{ fontFamily: "Roboto, sans-serif", letterSpacing: "0.18em" }}
        >
          AZA.
        </span>
      </div>

      {/* Greeting + Balance */}
      <div
        className="mx-5 mt-3 px-4 py-4 rounded-2xl flex items-center gap-3"
        style={{ background: "#141620", border: "1px solid rgba(255,255,255,0.06)" }}
      >
        <img
          src={imgAvatar}
          alt="Avatar"
          className="w-11 h-11 rounded-full object-cover shrink-0"
        />
        <div className="flex-1 min-w-0">
          <p
            className="text-white font-bold text-base leading-tight"
            style={{ fontFamily: "Roboto, sans-serif" }}
          >
            Hi, Dove
          </p>
          <p
            className="text-xs mt-0.5"
            style={{ fontFamily: "Roboto, sans-serif", color: "#6A7585" }}
          >
            Your available balance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <p
            className="text-white font-semibold text-base"
            style={{ fontFamily: "IBM Plex Sans, sans-serif" }}
          >
            {balanceVisible ? "₦200,590.00" : "₦••••••••"}
          </p>
          <button
            onClick={() => setBalanceVisible((v) => !v)}
            className="text-white/40 hover:text-white/70 transition-colors"
          >
            {balanceVisible ? <Eye size={16} /> : <EyeOff size={16} />}
          </button>
        </div>
      </div>

      {/* Action Bar */}
      <div
        className="mx-5 mt-3 px-4 py-4 rounded-xl flex items-center justify-around"
        style={{ background: "#000000" }}
      >
        {[
          {
            icon: <PlusCircle size={19} strokeWidth={1.5} />,
            label: "Fund Wallet",
          },
          { icon: <Navigation size={19} strokeWidth={1.5} />, label: "Sell" },
          {
            icon: <ArrowDownToLine size={19} strokeWidth={1.5} />,
            label: "Withdraw",
          },
        ].map(({ icon, label }) => (
          <button
            key={label}
            className="flex flex-col items-center gap-1 text-white active:opacity-70 transition-opacity"
          >
            {icon}
            <span
              className="text-[10px] font-bold"
              style={{ fontFamily: "Roboto, sans-serif" }}
            >
              {label}
            </span>
          </button>
        ))}
      </div>

      {/* Service Grid */}
      <div
        className="mx-5 mt-3 px-3 pt-8 pb-4 rounded-2xl"
        style={{ background: "#101218", border: "1px solid rgba(255,255,255,0.05)" }}
      >
        <div className="grid grid-cols-4 gap-y-5">
          {services.map(({ icon, label, color }) => (
            <button
              key={label}
              className="flex flex-col items-center gap-1.5 active:opacity-70 transition-opacity"
            >
              <div
                className="w-9 h-9 flex items-center justify-center rounded-xl"
                style={{ background: color + "22", color }}
              >
                {icon}
              </div>
              <span
                className="text-[9px] font-bold text-center leading-tight"
                style={{ fontFamily: "Roboto, sans-serif", color: "#6A7585" }}
              >
                {label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Promotional Banners */}
      <div className="mt-3 pl-5 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
        <div className="flex gap-3 w-max pr-5">
          {/* Banner 1 - pink */}
          <div
            className="w-[220px] h-[100px] rounded-xl relative overflow-hidden shrink-0"
            style={{ background: "#FCB3C5" }}
          >
            <div className="absolute left-3 top-3 flex flex-col gap-1">
              <p
                className="text-black font-bold text-base leading-tight"
                style={{ fontFamily: "Roboto, sans-serif" }}
              >
                50% OFF
              </p>
              <p
                className="text-black font-bold text-[11px]"
                style={{ fontFamily: "Roboto, sans-serif" }}
              >
                Summer special deal
              </p>
              <p
                className="text-[#3A2030] text-[9px] leading-snug"
                style={{ fontFamily: "Roboto, sans-serif", maxWidth: 110 }}
              >
                Get discount for every transaction this weekend
              </p>
            </div>
          </div>
          {/* Banner 2 - blue */}
          <div
            className="w-[220px] h-[100px] rounded-xl relative overflow-hidden shrink-0"
            style={{ background: "#D6E1FF" }}
          >
            <div className="absolute left-3 top-3 flex flex-col gap-1">
              <p
                className="text-black font-bold text-base leading-tight"
                style={{ fontFamily: "Manrope, sans-serif" }}
              >
                50% OFF
              </p>
              <p
                className="text-black font-bold text-[11px]"
                style={{ fontFamily: "Manrope, sans-serif" }}
              >
                Black friday deal
              </p>
              <p
                className="text-[#2A3050] text-[9px] leading-snug"
                style={{ fontFamily: "Manrope, sans-serif", maxWidth: 110 }}
              >
                Get discount for every top up and payment
              </p>
            </div>
          </div>
          {/* Banner 3 - yellow */}
          <div
            className="w-[220px] h-[100px] rounded-xl relative overflow-hidden shrink-0"
            style={{ background: "#FFF2CF" }}
          >
            <div className="absolute left-3 top-3 flex flex-col gap-1">
              <p
                className="text-black font-bold text-base leading-tight"
                style={{ fontFamily: "Manrope, sans-serif" }}
              >
                50% OFF
              </p>
              <p
                className="text-black font-bold text-[11px]"
                style={{ fontFamily: "Manrope, sans-serif" }}
              >
                Black friday deal
              </p>
              <p
                className="text-[#504020] text-[9px] leading-snug"
                style={{ fontFamily: "Manrope, sans-serif", maxWidth: 110 }}
              >
                Get discount for every top up and payment
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="mx-5 mt-3 mb-2">
        <div className="flex items-center justify-between mb-3">
          <p
            className="text-white font-semibold text-lg"
            style={{ fontFamily: "IBM Plex Sans, sans-serif" }}
          >
            Recent Transaction
          </p>
          <button
            className="text-xs font-semibold flex items-center gap-0.5 active:opacity-70"
            style={{ fontFamily: "Roboto, sans-serif", color: "#6A99D0" }}
          >
            See All <ChevronRight size={12} />
          </button>
        </div>

        <div className="flex flex-col gap-2">
          {transactions.map(
            ({ icon, iconBg, iconColor, title, date, amount, positive }) => (
              <div
                key={title}
                className="flex items-center gap-3 px-4 py-3 rounded-xl"
                style={{
                  background: "#141620",
                  border: "1px solid rgba(255,255,255,0.05)",
                }}
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: iconBg, color: iconColor }}
                >
                  {icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p
                    className="text-sm font-semibold text-white truncate"
                    style={{ fontFamily: "Roboto, sans-serif" }}
                  >
                    {title}
                  </p>
                  <p
                    className="text-[11px] mt-0.5"
                    style={{ fontFamily: "Roboto, sans-serif", color: "#4A5568" }}
                  >
                    {date}
                  </p>
                </div>
                <p
                  className="text-sm font-extrabold shrink-0"
                  style={{
                    fontFamily: "Manrope, sans-serif",
                    color: positive ? "#00D17E" : "#FF3366",
                  }}
                >
                  {amount}
                </p>
              </div>
            )
          )}
        </div>
      </div>

      {/* Spacer for bottom nav */}
      <div className="h-20 shrink-0" />

      {/* Bottom Navigation */}
      <div
        className="fixed bottom-0 left-1/2"
        style={{
          transform: "translateX(-50%)",
          width: 390,
          maxWidth: "100%",
          zIndex: 50,
        }}
      >
        <div
          className="mx-4 mb-4 px-2 py-3 rounded-full flex items-center justify-around"
          style={{ background: "#000000", boxShadow: "0 -2px 24px rgba(0,0,0,0.8)" }}
        >
          {[
            { icon: <Home size={20} strokeWidth={1.5} />, label: "Home" },
            {
              icon: <CreditCard size={20} strokeWidth={1.5} />,
              label: "Cards",
              active: true,
            },
            { icon: <History size={20} strokeWidth={1.5} />, label: "History" },
          ].map(({ icon, label, active }, i) => (
            <button
              key={label}
              onClick={() => setActiveNav(i)}
              className="flex flex-col items-center gap-1 px-6 py-1 rounded-full transition-all"
              style={{
                background:
                  activeNav === i ? "rgba(255,255,255,0.15)" : "transparent",
              }}
            >
              <span style={{ color: activeNav === i ? "white" : "rgba(255,255,255,0.35)" }}>
                {icon}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── APP ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<"onboarding" | "dashboard">("onboarding");

  return (
    <div
      className="min-h-screen flex items-center justify-center"
      style={{ background: "#040608" }}
    >
      {/* Phone frame */}
      <div
        className="relative overflow-hidden"
        style={{
          width: 390,
          height: 844,
          borderRadius: 44,
          boxShadow:
            "0 0 0 1px rgba(255,255,255,0.08), 0 32px 80px rgba(0,0,0,0.8), 0 0 0 8px #111318",
        }}
      >
        {screen === "onboarding" ? (
          <OnboardingScreen onNavigate={() => setScreen("dashboard")} />
        ) : (
          <DashboardScreen />
        )}
      </div>
    </div>
  );
}
