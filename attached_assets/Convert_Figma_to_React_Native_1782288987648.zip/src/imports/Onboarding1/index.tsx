import svgPaths from "./svg-nzsguoqu0m";
import imgLkd from "./77dcff6aeaa5b3e1fa00ad6a7d0bb6ce4dc11c95.png";
import imgEWallet1 from "./2834e1bb0bf08d81d90ee9230673f42dab798c47.png";

function Button1() {
  return (
    <div className="bg-black content-stretch flex items-center justify-center px-[12.601px] py-[9.451px] relative rounded-[3.15px] shrink-0 w-[263.052px]" data-name="Button">
      <p className="[word-break:break-word] font-['Roboto:SemiBold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#f8f8f8] text-[12.601px] whitespace-nowrap" style={{ fontVariationSettings: '"wdth" 100' }}>
        Login
      </p>
    </div>
  );
}

function Button2() {
  return (
    <div className="content-stretch flex items-center justify-center px-[12.601px] py-[9.451px] relative rounded-[3.15px] shrink-0 w-[263.84px]" data-name="Button">
      <div aria-hidden className="absolute border-[0.788px] border-black border-solid inset-0 pointer-events-none rounded-[3.15px]" />
      <p className="[word-break:break-word] font-['Roboto:SemiBold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[12.601px] text-black whitespace-nowrap" style={{ fontVariationSettings: '"wdth" 100' }}>
        Sign Up
      </p>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[6.301px] h-[109px] items-start left-[69px] top-[659px] w-[351px]" data-name="Button">
      <Button1 />
      <Button2 />
    </div>
  );
}

function Text() {
  return (
    <div className="[word-break:break-word] absolute content-stretch flex flex-col gap-[6.301px] h-[99px] items-center left-[33px] text-center top-[560px] w-[328px] whitespace-nowrap" data-name="Text">
      <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold leading-[1.2] relative shrink-0 text-[#0b0a0a] text-[25.203px]">Withdraw like a Boss</p>
      <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#616263] text-[12.601px]" style={{ fontVariationSettings: '"wdth" 100' }}>
        buy your gift card on aza
      </p>
    </div>
  );
}

function Indicator() {
  return (
    <div className="absolute contents left-[175.08px] top-[517.9px]" data-name="Indicator">
      <div className="absolute bg-[#d0d3d8] left-[175.08px] rounded-[1.575px] size-[8.387px] top-[517.9px]">
        <div aria-hidden className="absolute border-[#0b0a0a] border-[1.575px] border-solid inset-[-1.575px] pointer-events-none rounded-[3.15px]" />
      </div>
      <div className="absolute bg-[#d0d3d8] left-[191.85px] rounded-[1.575px] size-[8.387px] top-[517.9px]" />
      <div className="absolute bg-[#d0d3d8] left-[208.63px] rounded-[1.575px] size-[8.387px] top-[517.9px]" />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute h-[8.93px] right-[10.95px] top-[13.65px] w-[52.501px]" data-name="Group">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52.5011 8.92992">
        <g id="Group">
          <g id="Battery">
            <rect height="8.13835" id="Border" opacity="0.35" rx="1.70643" stroke="var(--stroke-0, #121208)" strokeOpacity="0.6" strokeWidth="0.787582" width="16.5392" x="33.7346" y="0.397788" />
            <path d={svgPaths.p1e311d80} fill="var(--fill-0, #121208)" fillOpacity="0.6" id="Cap" opacity="0.4" />
            <rect fill="var(--fill-0, #0B0B0B)" height="5.7756" id="Capacity" rx="1.05011" width="14.1765" x="34.916" y="1.57965" />
          </g>
          <path d={svgPaths.p30c7280} fill="var(--fill-0, #0B0B0B)" id="Wifi" />
          <path d={svgPaths.p8397c00} fill="var(--fill-0, #0B0B0B)" id="Cellular Connection" />
        </g>
      </svg>
    </div>
  );
}

function BlackStatusBar() {
  return (
    <div className="absolute h-[46px] left-0 overflow-clip top-0 w-[393px]" data-name="Black - Status bar">
      <Group />
      <div className="absolute h-[16.539px] left-[16.54px] top-[9.45px] w-[42.529px]" data-name="Time">
        <p className="[word-break:break-word] absolute font-['Manrope:SemiBold',sans-serif] font-semibold leading-[0] left-0 right-0 text-[#0b0b0b] text-[8.68px] text-center top-[calc(50%-5.91px)] tracking-[-0.2205px]">
          <span className="leading-[9.925px]">9:4</span>
          <span className="leading-[9.925px]">1</span>
        </p>
      </div>
    </div>
  );
}

export default function Onboarding() {
  return (
    <div className="bg-white overflow-clip relative rounded-[20px] size-full" data-name="Onboarding 1">
      <div className="absolute bg-white h-[484px] left-0 top-0 w-[393px]" />
      <Button />
      <Text />
      <Indicator />
      <BlackStatusBar />
      <div className="absolute h-[19px] left-[150px] top-[51px] w-[87px]" data-name="lkd">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgLkd} />
      </div>
      <div className="absolute left-[38px] size-[334px] top-[92px]" data-name="E-Wallet 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgEWallet1} />
      </div>
      <div className="absolute bg-white h-[19px] left-[166px] top-[156px] w-[66px]" />
      <div className="absolute bg-white h-[19px] left-[166px] top-[205px] w-[66px]" />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['NIKEA:Regular',sans-serif] h-[24px] leading-[22px] left-[196.5px] not-italic text-[#263238] text-[9px] text-center top-[156px] w-[109px]">Withdraw</p>
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['NIKEA:Regular',sans-serif] h-[25px] leading-[22px] left-[196.5px] not-italic text-[#263238] text-[7px] text-center top-[205px] w-[109px]">₦200,000</p>
    </div>
  );
}