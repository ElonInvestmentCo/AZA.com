
  # Convert Figma to React Native

  This is a code bundle for Convert Figma to React Native. The original project is available at https://www.figma.com/design/kg3bLh2qO7KLQD2RRD8LA8/Convert-Figma-to-React-Native.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  