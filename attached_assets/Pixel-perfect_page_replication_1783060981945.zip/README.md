
  # Pixel-perfect page replication

  This is a code bundle for Pixel-perfect page replication. The original project is available at https://www.figma.com/design/XI12mshlJQSnCy4YFzm0CL/Pixel-perfect-page-replication.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  