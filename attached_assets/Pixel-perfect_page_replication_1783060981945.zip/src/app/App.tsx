import { useState, useRef, useCallback } from "react";
import { motion, useMotionValue, useTransform, animate } from "motion/react";
import { ArrowLeft } from "lucide-react";

const SLIDES = [
  {
    id: "virtual",
    label: "Virtual",
    cardColor: "#6B7FD4",
    cardGlow: "rgba(107,127,212,0.4)",
    cardLabel: "VIRTUAL",
    buttonColor: "#4B63CC",
    buttonShadow: "0 8px 28px rgba(75,99,204,0.5)",
    buttonText: "Get virtual card",
    description:
      "Instant and ready to use online. Add to Apple Pay and use it to pay in stores, just like a physical card.",
  },
  {
    id: "disposable",
    label: "Disposable virtual",
    cardColor: "#F472B6",
    cardGlow: "rgba(244,114,182,0.4)",
    cardLabel: "DISPOSABLE VIRTUAL",
    buttonColor: "#EC4899",
    buttonShadow: "0 8px 28px rgba(236,72,153,0.5)",
    buttonText: "Get disposable virtual card",
    description:
      "Add an extra layer of security with our disposable virtual cards. Your details automatically change each time you make a payment, protecting you from fraud.",
  },
];

function MastercardLogo() {
  return (
    <div className="flex flex-col items-start gap-0.5">
      <div className="relative" style={{ width: 44, height: 28 }}>
        <div className="absolute left-0 top-0 rounded-full" style={{ width: 28, height: 28, background: "#EB001B" }} />
        <div className="absolute rounded-full" style={{ left: 16, top: 0, width: 28, height: 28, background: "#F79E1B" }} />
      </div>
      <span style={{ color: "rgba(255,255,255,0.88)", fontSize: 9, fontWeight: 500, letterSpacing: "0.04em", fontFamily: "Inter,sans-serif" }}>
        mastercard
      </span>
    </div>
  );
}

function RevolutMark() {
  return (
    <div style={{ width: 40, height: 40, borderRadius: 10, background: "rgba(255,255,255,0.18)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <span style={{ color: "white", fontSize: 22, fontWeight: 700, fontFamily: "Inter,sans-serif", lineHeight: 1 }}>R</span>
    </div>
  );
}

function Card({ slide }: { slide: typeof SLIDES[0] }) {
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        borderRadius: 28,
        background: slide.cardColor,
        boxShadow: `0 24px 64px ${slide.cardGlow}, 0 4px 12px rgba(0,0,0,0.06)`,
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Highlight blob */}
      <div style={{
        position: "absolute",
        top: "22%", left: "50%",
        transform: "translate(-50%,-50%)",
        width: "60%", height: "45%",
        borderRadius: "50%",
        background: "rgba(255,255,255,0.14)",
        filter: "blur(20px)",
        pointerEvents: "none",
      }} />

      {/* Card number watermark */}
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none" }}>
        <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 13, fontWeight: 500, letterSpacing: "0.2em", fontFamily: "Inter,sans-serif" }}>
          8003 6071 0534 6352
        </span>
      </div>

      {/* Left rotated: CARD HOLDER */}
      <div style={{ position: "absolute", left: 24, top: "50%", transform: "translateY(-50%) rotate(-90deg)", transformOrigin: "center center", whiteSpace: "nowrap" }}>
        <span style={{ color: "rgba(255,255,255,0.72)", fontSize: 11, fontWeight: 600, letterSpacing: "0.24em", textTransform: "uppercase", fontFamily: "Inter,sans-serif" }}>
          CARD HOLDER
        </span>
      </div>

      {/* Right rotated: card type */}
      <div style={{ position: "absolute", right: 20, top: "50%", transform: "translateY(-50%) rotate(90deg)", transformOrigin: "center center", whiteSpace: "nowrap" }}>
        <span style={{ color: "rgba(255,255,255,0.72)", fontSize: 10, fontWeight: 600, letterSpacing: "0.2em", textTransform: "uppercase", fontFamily: "Inter,sans-serif" }}>
          {slide.cardLabel}
        </span>
      </div>

      {/* Bottom row */}
      <div style={{ position: "absolute", bottom: 22, left: 22, right: 22, display: "flex", alignItems: "flex-end", justifyContent: "space-between" }}>
        <MastercardLogo />
        <RevolutMark />
      </div>
    </div>
  );
}

export default function App() {
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const x = useMotionValue(0);

  const getWidth = () => containerRef.current?.offsetWidth ?? 390;

  const snapTo = useCallback((index: number) => {
    const clamped = Math.max(0, Math.min(SLIDES.length - 1, index));
    setActiveIndex(clamped);
    animate(x, -clamped * getWidth(), {
      type: "spring",
      stiffness: 400,
      damping: 38,
      mass: 0.7,
    });
  }, [x]); // eslint-disable-line

  const handleDragEnd = (_: unknown, info: { offset: { x: number }; velocity: { x: number } }) => {
    const w = getWidth();
    const threshold = w * 0.2;
    let next = activeIndex;
    if (info.velocity.x < -300 || info.offset.x < -threshold) next = activeIndex + 1;
    else if (info.velocity.x > 300 || info.offset.x > threshold) next = activeIndex - 1;
    snapTo(next);
  };

  // 0 → 1 progress between slides
  const progress = useTransform(x, (v) => -v / getWidth());
  const slide0Alpha = useTransform(progress, [0, 0.5, 1], [1, 0, 0]);
  const slide1Alpha = useTransform(progress, [0, 0.5, 1], [0, 0, 1]);
  const alphas = [slide0Alpha, slide1Alpha];

  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "100%", minHeight: "100dvh", background: "#f0f0f4" }}>
      {/* Phone frame */}
      <div
        ref={containerRef}
        style={{
          position: "relative",
          display: "flex",
          flexDirection: "column",
          width: "min(100vw, 430px)",
          height: "min(100dvh, 860px)",
          background: "#ffffff",
          borderRadius: "clamp(0px, 5vw, 44px)",
          boxShadow: "0 40px 100px rgba(0,0,0,0.2)",
          overflow: "hidden",
        }}
      >
        {/* ── Header ── */}
        <div style={{ flexShrink: 0, display: "flex", alignItems: "center", paddingTop: 48, paddingBottom: 8, paddingLeft: 20, paddingRight: 20, position: "relative" }}>
          <button style={{ display: "flex", alignItems: "center", justifyContent: "center", width: 36, height: 36, borderRadius: "50%", border: "none", background: "none", cursor: "pointer", color: "#111" }}>
            <ArrowLeft size={22} strokeWidth={2.3} />
          </button>
          <span style={{ position: "absolute", left: 0, right: 0, textAlign: "center", fontFamily: "Inter,sans-serif", fontWeight: 700, fontSize: 17, color: "#111", letterSpacing: "-0.01em", pointerEvents: "none" }}>
            Choose a card type
          </span>
        </div>

        {/* ── Card drag zone (clips strictly) ── */}
        <div
          style={{ flexShrink: 0, width: "100%", overflow: "hidden", touchAction: "pan-y" }}
        >
          <motion.div
            drag="x"
            dragConstraints={{ left: -(SLIDES.length - 1) * getWidth(), right: 0 }}
            dragElastic={0.08}
            onDragEnd={handleDragEnd}
            style={{ x, display: "flex", width: `${SLIDES.length * 100}%`, cursor: "grab" }}
            whileDrag={{ cursor: "grabbing" }}
          >
            {SLIDES.map((slide) => (
              <div
                key={slide.id}
                style={{
                  width: `${100 / SLIDES.length}%`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  paddingTop: 24,
                  paddingBottom: 28,
                }}
              >
                {/* Card wrapper — fixed aspect ratio */}
                <div
                  style={{
                    width: "78%",
                    aspectRatio: "0.63 / 1",
                    maxHeight: "clamp(300px, 50vh, 460px)",
                    maxWidth: 310,
                  }}
                >
                  <Card slide={slide} />
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* ── Bottom UI (cross-fades, never drags) ── */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between", paddingBottom: 36 }}>
          {/* Tabs */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 24, paddingTop: 4, paddingBottom: 4 }}>
            {SLIDES.map((s, i) => (
              <TabButton key={s.id} label={s.label} index={i} progress={progress} onClick={() => snapTo(i)} />
            ))}
          </div>

          {/* Description */}
          <div style={{ position: "relative", flex: 1, display: "flex", alignItems: "center" }}>
            {SLIDES.map((slide, i) => (
              <motion.p
                key={slide.id}
                style={{
                  opacity: alphas[i],
                  position: "absolute",
                  left: 32, right: 32,
                  fontFamily: "Inter,sans-serif",
                  fontSize: 15,
                  fontWeight: 400,
                  color: "#999",
                  lineHeight: 1.55,
                  letterSpacing: "-0.005em",
                  textAlign: "center",
                  margin: 0,
                  pointerEvents: i === activeIndex ? "auto" : "none",
                }}
              >
                {slide.description}
              </motion.p>
            ))}
          </div>

          {/* CTA Button */}
          <div style={{ position: "relative", paddingLeft: 20, paddingRight: 20, height: 58 }}>
            {SLIDES.map((slide, i) => (
              <motion.button
                key={slide.id}
                style={{
                  opacity: alphas[i],
                  position: "absolute",
                  left: 20, right: 20,
                  background: slide.buttonColor,
                  boxShadow: slide.buttonShadow,
                  borderRadius: 100,
                  height: 58,
                  fontFamily: "Inter,sans-serif",
                  fontSize: 17,
                  fontWeight: 600,
                  color: "white",
                  border: "none",
                  cursor: "pointer",
                  letterSpacing: "-0.01em",
                  pointerEvents: i === activeIndex ? "auto" : "none",
                }}
                whileTap={{ scale: 0.97 }}
              >
                {slide.buttonText}
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function TabButton({
  label,
  index,
  progress,
  onClick,
}: {
  label: string;
  index: number;
  progress: ReturnType<typeof useTransform>;
  onClick: () => void;
}) {
  const activeVal = useTransform(progress, (p) => Math.max(0, 1 - Math.abs(p - index)));
  const color = useTransform(activeVal, [0, 1], ["#b0b0b0", "#111111"]);

  return (
    <motion.button onClick={onClick} style={{ position: "relative", background: "none", border: "none", padding: "6px 0", cursor: "pointer" }}>
      {/* Width anchor (hidden bold copy) */}
      <span style={{ visibility: "hidden", fontWeight: 700, fontSize: 17, fontFamily: "Inter,sans-serif", letterSpacing: "-0.01em", display: "block" }}>
        {label}
      </span>
      {/* Normal weight */}
      <motion.span style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Inter,sans-serif", fontSize: 17, fontWeight: 400, letterSpacing: "-0.01em", color, opacity: useTransform(activeVal, [0, 1], [1, 0]) }}>
        {label}
      </motion.span>
      {/* Bold weight */}
      <motion.span style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Inter,sans-serif", fontSize: 17, fontWeight: 700, letterSpacing: "-0.01em", color: "#111", opacity: activeVal }}>
        {label}
      </motion.span>
    </motion.button>
  );
}
