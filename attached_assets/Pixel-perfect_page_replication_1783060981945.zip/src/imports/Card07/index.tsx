import svgPaths from "./svg-x6xfj5lbuw";

function Icon() {
  return (
    <div className="absolute h-[45.5px] left-[13px] top-[2px] w-[28px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 45.5">
        <g id="Icon">
          <circle cx="14" cy="31.5" fill="var(--fill-0, #8282B0)" id="Ellipse 3" r="13.625" stroke="var(--stroke-0, #C1C1D7)" strokeWidth="0.75" transform="rotate(90 14 31.5)" />
          <circle cx="14" cy="14" fill="var(--fill-0, #28283E)" id="Ellipse 2" r="13.625" stroke="var(--stroke-0, #C1C1D7)" strokeWidth="0.75" transform="rotate(90 14 14)" />
          <g id="Intersect" opacity="0.2">
            <mask fill="white" id="path-3-inside-1_4_148">
              <path d={svgPaths.p103cc80} />
            </mask>
            <path d={svgPaths.p103cc80} fill="var(--fill-0, #8282B0)" />
            <path d={svgPaths.p8ac9200} fill="var(--stroke-0, #C1C1D7)" mask="url(#path-3-inside-1_4_148)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function PaymentMethod() {
  return (
    <div className="absolute h-[49px] left-[263px] overflow-clip top-[17px] w-[41px]" data-name="Payment Method">
      <Icon />
      <div className="absolute flex h-[49px] items-center justify-center left-0 top-0 w-[11px]">
        <div className="flex-none rotate-90">
          <p className="[word-break:break-word] font-['Inter:Medium',sans-serif] font-medium leading-[normal] lowercase not-italic relative text-[9px] text-white whitespace-nowrap">mastercard</p>
        </div>
      </div>
    </div>
  );
}

function Rfid() {
  return (
    <div className="absolute inset-[51.81%_9.94%_36.58%_80.42%]" data-name="RFID">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 24.381">
        <g clipPath="url(#clip0_4_143)" id="RFID">
          <rect fill="url(#paint0_linear_4_143)" height="24.381" id="Rectangle" rx="4.66667" width="32" />
          <path d={svgPaths.p1712c980} id="Vector" stroke="var(--stroke-0, #262626)" strokeWidth="0.583333" />
          <path d={svgPaths.p16dd4220} id="Vector_2" stroke="var(--stroke-0, #262626)" strokeWidth="0.583333" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_4_143" x1="-3.2" x2="34.4" y1="12.1906" y2="12.1906">
            <stop offset="0.120245" stopColor="#D5B688" />
            <stop offset="0.469278" stopColor="#FCF7B7" />
            <stop offset="1" stopColor="#E8DFA5" />
          </linearGradient>
          <clipPath id="clip0_4_143">
            <rect fill="white" height="24.381" width="32" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Chips() {
  return (
    <div className="absolute flex items-center justify-center left-[267px] size-[32px] top-[162px]">
      <div className="flex-none rotate-90">
        <div className="relative size-[32px]" data-name="Chips">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
            <g id="Chips ">
              <path d={svgPaths.p18391980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute h-[65px] left-[79px] top-[175px] w-[160px]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 160 65">
        <g id="Frame 252">
          <path d={svgPaths.p3a55f1d0} fill="var(--fill-0, white)" id="Rectangle 35" />
          <path d={svgPaths.p31161300} fill="var(--fill-0, white)" id="Rectangle 36" />
          <path d={svgPaths.p1cb54900} fill="var(--fill-0, white)" id="Rectangle 37" />
          <path d={svgPaths.pcbe3b80} fill="var(--fill-0, white)" id="Rectangle 38" />
        </g>
      </svg>
    </div>
  );
}

export default function Card() {
  return (
    <div className="bg-[rgba(116,109,53,0.77)] overflow-clip relative rounded-[12px] size-full" style={{ containerType: "size" }} data-name="Card 07">
      <PaymentMethod />
      <Rfid />
      <Chips />
      <div className="absolute flex h-[73px] items-center justify-center left-[calc(50%-153px)] top-[63px] w-[20px]">
        <div className="flex-none rotate-90">
          <p className="[word-break:break-word] font-['Gugi:Regular',sans-serif] leading-[normal] not-italic relative text-[16px] text-white tracking-[-0.32px] whitespace-nowrap">PAYVORA</p>
        </div>
      </div>
      <Frame />
    </div>
  );
}