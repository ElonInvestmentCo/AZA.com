
  # CHOOSE_A_CARD_TYPE

  This is a code bundle for CHOOSE_A_CARD_TYPE. The original project is available at https://www.figma.com/design/XI12mshlJQSnCy4YFzm0CL/CHOOSE_A_CARD_TYPE.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  