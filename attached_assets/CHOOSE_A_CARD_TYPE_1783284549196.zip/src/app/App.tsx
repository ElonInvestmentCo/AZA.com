import { useState, useRef, useCallback } from "react";
import { motion, useMotionValue, useTransform, animate } from "motion/react";
import { ArrowLeft } from "lucide-react";
import card06Raw from "@/imports/Card_06.svg?raw";
import card07Raw from "@/imports/Card_07.svg?raw";

const SLIDES = [
  {
    id: "virtual",
    label: "Virtual",
    cardRaw: card06Raw,
    cardShadow: "0 24px 60px rgba(40,60,58,0.38), 0 6px 16px rgba(0,0,0,0.14)",
    buttonColor: "#283C3A",
    buttonShadow: "0 8px 28px rgba(40,60,58,0.45)",
    buttonText: "Get virtual card",
    description:
      "Instant and ready to use online. Add to Apple Pay and use it to pay in stores, just like a physical card.",
  },
  {
    id: "premium",
    label: "Premium",
    cardRaw: card07Raw,
    cardShadow: "0 24px 60px rgba(116,109,53,0.4), 0 6px 16px rgba(0,0,0,0.12)",
    buttonColor: "#5C5628",
    buttonShadow: "0 8px 28px rgba(116,109,53,0.45)",
    buttonText: "Get premium card",
    description:
      "Unlock exclusive benefits and worldwide acceptance with our premium metal-finish card.",
  },
];

// Strip fixed px dimensions from the root <svg> so it fills its CSS container
function responsiveSvg(raw: string): string {
  return raw.replace(
    /(<svg[^>]*)\s+width="[^"]*"\s+height="[^"]*"/,
    '$1 width="100%" height="100%"'
  );
}

export default function App() {
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const x = useMotionValue(0);

  const getWidth = () => containerRef.current?.offsetWidth ?? 390;

  const snapTo = useCallback((index: number) => {
    const clamped = Math.max(0, Math.min(SLIDES.length - 1, index));
    setActiveIndex(clamped);
    animate(x, -clamped * getWidth(), {
      type: "spring",
      stiffness: 400,
      damping: 38,
      mass: 0.7,
    });
  }, [x]); // eslint-disable-line

  const handleDragEnd = (_: unknown, info: { offset: { x: number }; velocity: { x: number } }) => {
    const w = getWidth();
    const threshold = w * 0.2;
    let next = activeIndex;
    if (info.velocity.x < -300 || info.offset.x < -threshold) next = activeIndex + 1;
    else if (info.velocity.x > 300 || info.offset.x > threshold) next = activeIndex - 1;
    snapTo(next);
  };

  // 0 → 1 progress between slides
  const progress = useTransform(x, (v) => -v / getWidth());
  const slide0Alpha = useTransform(progress, [0, 0.5, 1], [1, 0, 0]);
  const slide1Alpha = useTransform(progress, [0, 0.5, 1], [0, 0, 1]);
  const alphas = [slide0Alpha, slide1Alpha];

  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "100%", minHeight: "100dvh", background: "#f0f0f4" }}>
      {/* Phone frame */}
      <div
        ref={containerRef}
        style={{
          position: "relative",
          display: "flex",
          flexDirection: "column",
          width: "min(100vw, 430px)",
          height: "min(100dvh, 860px)",
          background: "#ffffff",
          borderRadius: "clamp(0px, 5vw, 44px)",
          boxShadow: "0 40px 100px rgba(0,0,0,0.2)",
          overflow: "hidden",
        }}
      >
        {/* ── Header ── */}
        <div style={{ flexShrink: 0, display: "flex", alignItems: "center", paddingTop: 48, paddingBottom: 8, paddingLeft: 20, paddingRight: 20, position: "relative" }}>
          <button style={{ display: "flex", alignItems: "center", justifyContent: "center", width: 36, height: 36, borderRadius: "50%", border: "none", background: "none", cursor: "pointer", color: "#111" }}>
            <ArrowLeft size={22} strokeWidth={2.3} />
          </button>
          <span style={{ position: "absolute", left: 0, right: 0, textAlign: "center", fontFamily: "Inter,sans-serif", fontWeight: 700, fontSize: 17, color: "#111", letterSpacing: "-0.01em", pointerEvents: "none" }}>
            Choose a card type
          </span>
        </div>

        {/* ── Card drag zone — height capped so bottom UI is never clipped ── */}
        <div
          style={{
            flexShrink: 0,
            width: "100%",
            overflow: "hidden",
            touchAction: "pan-y",
            /* Never taller than 52 vh so tabs + description + button always fit */
            maxHeight: "clamp(280px, 52vh, 500px)",
          }}
        >
          <motion.div
            drag="x"
            dragConstraints={{ left: -(SLIDES.length - 1) * getWidth(), right: 0 }}
            dragElastic={0.08}
            onDragEnd={handleDragEnd}
            style={{ x, display: "flex", width: `${SLIDES.length * 100}%`, cursor: "grab", height: "100%" }}
            whileDrag={{ cursor: "grabbing" }}
          >
            {SLIDES.map((slide) => (
              <div
                key={slide.id}
                style={{
                  width: `${100 / SLIDES.length}%`,
                  height: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  paddingTop: 20,
                  paddingBottom: 20,
                  paddingLeft: 28,
                  paddingRight: 28,
                  boxSizing: "border-box",
                }}
              >
                {/*
                  SVG width/height attrs replaced with 100% so it fills the
                  aspect-ratio wrapper instead of overflowing at 210×332 px.
                */}
                <div
                  style={{
                    /* Fill available height, width follows aspect ratio */
                    height: "100%",
                    aspectRatio: "210 / 332",
                    maxWidth: "100%",
                    borderRadius: 16,
                    overflow: "hidden",
                    boxShadow: slide.cardShadow,
                    flexShrink: 0,
                    display: "flex",
                  }}
                  dangerouslySetInnerHTML={{ __html: responsiveSvg(slide.cardRaw) }}
                />
              </div>
            ))}
          </motion.div>
        </div>

        {/* ── Bottom UI (cross-fades, never drags) ── */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between", paddingBottom: 36 }}>
          {/* Tabs */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 24, paddingTop: 4, paddingBottom: 4 }}>
            {SLIDES.map((s, i) => (
              <TabButton key={s.id} label={s.label} index={i} progress={progress} onClick={() => snapTo(i)} />
            ))}
          </div>

          {/* Description */}
          <div style={{ position: "relative", flex: 1, display: "flex", alignItems: "center" }}>
            {SLIDES.map((slide, i) => (
              <motion.p
                key={slide.id}
                style={{
                  opacity: alphas[i],
                  position: "absolute",
                  left: 32, right: 32,
                  fontFamily: "Inter,sans-serif",
                  fontSize: 15,
                  fontWeight: 400,
                  color: "#999",
                  lineHeight: 1.55,
                  letterSpacing: "-0.005em",
                  textAlign: "center",
                  margin: 0,
                  pointerEvents: i === activeIndex ? "auto" : "none",
                }}
              >
                {slide.description}
              </motion.p>
            ))}
          </div>

          {/* CTA Button */}
          <div style={{ position: "relative", paddingLeft: 20, paddingRight: 20, height: 58 }}>
            {SLIDES.map((slide, i) => (
              <motion.button
                key={slide.id}
                style={{
                  opacity: alphas[i],
                  position: "absolute",
                  left: 20, right: 20,
                  background: slide.buttonColor,
                  boxShadow: slide.buttonShadow,
                  borderRadius: 100,
                  height: 58,
                  fontFamily: "Inter,sans-serif",
                  fontSize: 17,
                  fontWeight: 600,
                  color: "white",
                  border: "none",
                  cursor: "pointer",
                  letterSpacing: "-0.01em",
                  pointerEvents: i === activeIndex ? "auto" : "none",
                }}
                whileTap={{ scale: 0.97 }}
              >
                {slide.buttonText}
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function TabButton({
  label,
  index,
  progress,
  onClick,
}: {
  label: string;
  index: number;
  progress: ReturnType<typeof useTransform>;
  onClick: () => void;
}) {
  const activeVal = useTransform(progress, (p) => Math.max(0, 1 - Math.abs(p - index)));
  const color = useTransform(activeVal, [0, 1], ["#b0b0b0", "#111111"]);

  return (
    <motion.button onClick={onClick} style={{ position: "relative", background: "none", border: "none", padding: "6px 0", cursor: "pointer" }}>
      {/* Width anchor (hidden bold copy) */}
      <span style={{ visibility: "hidden", fontWeight: 700, fontSize: 17, fontFamily: "Inter,sans-serif", letterSpacing: "-0.01em", display: "block" }}>
        {label}
      </span>
      {/* Normal weight */}
      <motion.span style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Inter,sans-serif", fontSize: 17, fontWeight: 400, letterSpacing: "-0.01em", color, opacity: useTransform(activeVal, [0, 1], [1, 0]) }}>
        {label}
      </motion.span>
      {/* Bold weight */}
      <motion.span style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Inter,sans-serif", fontSize: 17, fontWeight: 700, letterSpacing: "-0.01em", color: "#111", opacity: activeVal }}>
        {label}
      </motion.span>
    </motion.button>
  );
}
